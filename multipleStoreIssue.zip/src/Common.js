import React, { Component } from 'react';
import ChildB from './ChildB';

class Common extends Component {
  constructor(){
      super()
  }
  setFormValue(formData){
    var objClassB = new ChildB();
    objClassB.formDataA(formData);
  }

}

export default Common;
