import React, { Component } from 'react';
import ChildA from './ChildA';
import ChildB from './ChildB';
import ChildA1 from './ChildA1';
import ChildB1 from './ChildB1';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

class App extends Component {
  render(){
    return (
        <div>
          <div className="partentContainer">
            <div className="formContainer">
              <div className="childContainer">
                <ChildA/>
              </div>
              <div className="childContainer">
                <legend>Added Employee List</legend>
                <ChildB/>
              </div>
            </div>
            <div className="formContainer">
              <div className="childContainer">
                <ChildA1/>
              </div>
              <div className="childContainer">
                <legend>Added Employee List</legend>
                <ChildB1/>
              </div>
            </div>
          </div>
        </div>
    )
  }
}

export default App;
