import React, { Component } from 'react';
import { connect } from 'react-redux';
import Post1 from './Post1';

class ChildB1 extends Component {
	render() {
		return (
			<div>
				<h1>All Posts</h1>
        		{this.props.emp.map((employee) => <Post1 key={employee.empPhone} employee={employee} />)}
			</div>
		);
	}
}

const mapStateToProps = (state) => {
	return {
		emp: state
	}
}
export default connect(mapStateToProps)(ChildB1);
