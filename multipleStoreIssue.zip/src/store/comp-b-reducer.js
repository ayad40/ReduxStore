const reducerB = (stateb = [], action) =>{
    switch(action.type) {
        case 'SUBMIT_FORMB':
          return stateb.concat([action.data]);
        default:
          return stateb;
      }
}

export default reducerB;
