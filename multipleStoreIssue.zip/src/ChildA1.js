import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import {connect} from 'react-redux';

class ChildA1 extends Component {
  constructor(props){
    super(props)
    this.state={
      emp:[]
    }
    this.submitForm = this.submitForm.bind(this);
}
  
 
  submitForm(e) {
    let empObj = {
      empName : ReactDOM.findDOMNode(this.refs.Name).value ? ReactDOM.findDOMNode(this.refs.Name).value : "Ram",
      empEmail : ReactDOM.findDOMNode(this.refs.Email).value ? ReactDOM.findDOMNode(this.refs.Email).value : "ram@test.com",
      empPhone : ReactDOM.findDOMNode(this.refs.Phone).value ? ReactDOM.findDOMNode(this.refs.Phone).value : "1234567",
      empCategory : ReactDOM.findDOMNode(this.refs.Category).value ?ReactDOM.findDOMNode(this.refs.Category).value : "Doctor"
    }
    this.props.storeb.dispatch({
      type:'SUBMIT_FORMB',
      data:empObj});
  }

  render(){
    return (
        <div>
          <form>
            <fieldset>
              <legend>Add Employee Detail(Right Block)</legend>
              <p><input ref="Name" type="text"className="form-control" placeholder="Employee Name"/></p>
              <p><input ref="Email" type="text"className="form-control" placeholder="Employee Email"/></p>
              <p><input ref="Phone"  type="text"className="form-control" placeholder="Employee Phone No"/></p>
              <p><input ref="Category" type="text"className="form-control" placeholder="Employee Category"/></p>
              <input type="button" value="Add Employee" className="btn btn-primary" onClick={this.submitForm} />
            </fieldset>
          </form>
        </div>
      )
  }
}

export default connect()(ChildA1);
